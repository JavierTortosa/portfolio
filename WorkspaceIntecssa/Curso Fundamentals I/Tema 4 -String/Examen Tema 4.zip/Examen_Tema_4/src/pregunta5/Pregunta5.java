package pregunta5;

public class Pregunta5 {

	public static void main(String[] args) {

		/*
		Compara si el String “Java” es igual que el String “JavaScript”.
		*/
		
		String texto1 = "Java";
		String texto2 = "JavaScript";
		
		if (texto1.compareTo(texto2) == 0) {
			System.out.println("Son iguales");
		} else {
			System.out.println("No son iguales");
		}
		
		
		
	}

}
