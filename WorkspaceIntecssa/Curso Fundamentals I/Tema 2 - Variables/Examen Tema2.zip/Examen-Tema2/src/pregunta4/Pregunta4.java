package pregunta4;

public class Pregunta4 {

	static final int DIAS_SEMANA = 7;
	static final int DIAS_LABORABLES = 5;
	static final int MESES_DEL_AÑO = 12; 
	static final int DÍAS_DEL_AÑO = 365; 
	static final int HORAS_DEL_DÍA = 24;
	
	public static void main(String[] args) {
/*
		Declarar las siguientes variables como constantes. 
		a)	Días de la semana 
		b)	Días laborales 
		c)	Cantidad de meses del año 
		d)	Cantidad de días del año 
		e)	Cantidad de horas del día 
*/
	}

}
