package pregunta5;

public class Pregunta5 {
	
	static final int DIAS_SEMANA = 7;
	static final int DIAS_LABORABLES = 5;
	static final int MESES_DEL_AÑO = 12;
	static final int DÍAS_DEL_AÑO = 365;
	static final int HORAS_DEL_DÍA = 24;

	public static void main(String[] args) {

//		Mostrar las constantes del siguiente ejercicio en pantalla 

		// Imagino que lo que quieren es que muestre los valores de las constantes
		// del ejercicio anterior ya que no hay ningun ejercicio siguiente

		System.out.println("DIAS_SEMANA = "+DIAS_SEMANA);
		System.out.println("DIAS_LABORABLES = "+DIAS_LABORABLES);
		System.out.println("MESES_DEL_AÑO = "+MESES_DEL_AÑO);
		System.out.println("DÍAS_DEL_AÑO = "+DÍAS_DEL_AÑO);
		System.out.println("HORAS_DEL_DÍA = "+HORAS_DEL_DÍA);
	}
}
