package pregunta2;

public class Pregunta2 {

	public static void main(String[] args) {
/*
		Escribe la declaración más apropiada para cada una de las siguientes variables. 
		El nombre de cada una indica el tipo de dato que contendrá y servirá para determinar 
		el tipo de dato más adecuado en la declaración de la variable. 
		a)	edad                                                 
		b)	códigoPostal 
		c)	altura                                               
		d)	genero (valores: H: hombre, M: mujer)                    
		e)	nombre                                               
		f)	númeroDeHijos R. 
*/
		int edad;                                           
		String códigoPostal; //no le pongo int porque en principio no voy a operar con el
		float altura;  //por tipo mejor float pero normalmente se pone double                                               
		char genero;// (valores: H: hombre, M: mujer)                    
		String nombre;                                               
		int númeroDeHijos; 

	}
}
