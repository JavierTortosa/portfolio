package pregunta1;

public class Pregunta1 {

	public static void main(String[] args) {

		/*
		 * Escribe la declaración para cada una de las variables y asígnales un valor
		 * inicial en la propia declaración de variable. a) Variables enteras: p, q b)
		 * Variables float: x, y, z c) Variables carácter: a, b, c d) Variables double:
		 * raiz1, raiz2 e) Variable entera larga: contador f) Variable entera corta:
		 * indicador R.
		 */
		int p = 1;
		int q = 2;

		float x = 2.1f;
		float y = 2.2f;
		float z = 3.5f;

		char a = 'a';
		char b = 'b';
		char c = 'c';

		double raiz1 = 5.5;
		double raiz2 = 7.5;

		long contador = 525;

		short indicador = 21;
	}

}
