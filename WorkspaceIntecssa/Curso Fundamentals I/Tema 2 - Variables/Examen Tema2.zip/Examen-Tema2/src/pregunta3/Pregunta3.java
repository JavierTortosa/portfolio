package pregunta3;

public class Pregunta3 {

	public static void main(String[] args) {

		/*Declarar las siguientes variables en la misma línea con el mismo de datos: 
a)	X,y,z 
b)	Altura, Peso, Ancho 
c)	Nombre, Apellido Paterno, Apellido Materno R. 
*/
		int X,y,z;
		double Altura, Peso, Ancho;
		String nombre, apellidoPaterno, apellidoMaterno;
		
	}

}
