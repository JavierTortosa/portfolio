package pregunta10;

public class Pregunta10 {

	public static void main(String[] args) {

		/*
		Realizar un ejercicio que muestre los números del 100 al 1 utilizando la
		instrucción for.
		*/
		
		System.out.println("PREGUNTA 10");
		System.out.println("-----------");
		System.out.println("");
		
		System.out.println("del 100 al 1 con for\n");
		
		for (int i = 100; i>=1; i--) {
			System.out.println(i);
		}
	}
}
