package pregunta14;

import java.util.Scanner;

public class Pregunta14 {

	public static void main(String[] args) {

		/*
		Muestra los números primos entre 1 y 100
		
		Un número primo es aquel que solo es divisible entre si mismo y 1. 
		Los números negativos no pueden ser primos
		*/
		System.out.println("PREGUNTA 14");
		System.out.println("-----------");
		System.out.println("");
		
		Scanner numeroTeclado = new Scanner(System.in);
		
		int numero=0;
		boolean primo = false;
		int i=0;
		
		System.out.println("Introduce un numero para saber si es primo");
		numero = numeroTeclado.nextInt();
		
		for(i=numero-1; i>1; i--) {
			if(numero % i == 0) {
				primo=true;
				break;
			} 
		}
		
		if (numero < 0) {
			System.out.println("Un numero negativo no puede ser primo");
		}else {
			if(primo) {
				System.out.println("el numero "+ numero + " se puede dividir por "+i+" por lo tanto no es primo");
			} else {
				System.out.println("El numero es primo");
			}
		}
	}
}
