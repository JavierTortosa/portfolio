package pregunta08;

public class Pregunta8 {

	public static void main(String[] args) {

		/*
		Realizar un programa que muestre los números del 1 al 50 utilizando la
		instrucción while.
		*/
		
		System.out.println("PREGUNTA 8");
		System.out.println("-----------");
		System.out.println("");
		
		int numero =1;
		
		while (numero<=50) {
			System.out.println(numero);
			numero++;
		}
	}

}
