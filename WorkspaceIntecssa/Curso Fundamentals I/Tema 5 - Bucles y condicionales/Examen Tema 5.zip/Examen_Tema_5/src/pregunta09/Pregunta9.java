package pregunta09;

public class Pregunta9 {

	public static void main(String[] args) {

		/*
		Realizar el ejercicio anterior utilizando Do While
		*/
		
		System.out.println("PREGUNTA 9");
		System.out.println("-----------");
		System.out.println("");
		
		int numero =1;
		do {
			System.out.println(numero);
			numero++;
		} while (numero<=50);
	}
}
