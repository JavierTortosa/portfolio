package pregunta5;

public class Pregunta5 {

	public static void main(String[] args) {
/*
		Comparar las siguientes variables 
		a = 3 b = 4 c = 5 d = 6 
		Utilizar los operadores relacionales. 
*/
		int a = 3; 
		int b = 4; 
		int c = 5; 
		int d = 6;
		
		System.out.println(" a >  b " 	+ (a >  b));
		System.out.println(" a <  b " 	+ (a <  b));
		System.out.println(" a >= b " 	+ (a >= b));	
		System.out.println(" a <= b " 	+ (a <= b));
		System.out.println(" a == b " 	+ (a == b));
		System.out.println(" a != b " 	+ (a != b));
		System.out.println("");
		System.out.println(" c >  d " 	+ (c >  d));
		System.out.println(" c <  d " 	+ (c <  d));
		System.out.println(" c >= d " 	+ (c >= d));	
		System.out.println(" c <= d " 	+ (c <= d));
		System.out.println(" c == d " 	+ (c == d));
		System.out.println(" c != d " 	+ (c != d));
	}

}
