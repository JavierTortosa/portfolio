package pregunta2;

public class Pregunta2 {

	public static void main(String[] args) {
/*
		Mostrar el area de un cuadrado con un lado de 4 m². 
		Formula : L².  
*/
		
		double lado = Math.pow(4, 2);
		double area = Math.pow(lado, 2);
		System.out.println("el area es " + area);
	}

}
