package pregunta4;

public class Pregunta4 {

	public static void main(String[] args) {

		/*
		Realizar la conversión de dólares a euros, utilizando variables de tipo float 
		*/
		
		float dolares=500;
		float valorDolarEnEuros = 1.03f;
		
		float cambio = dolares * valorDolarEnEuros;
		System.out.println(dolares + " dolares son " + cambio +" euros");
		
	}

}
