package pregunta3;

import java.util.Scanner;

public class Pregunta3 {

	public static void main(String[] args) {
/*
		Mostrar el area de las siguientes figuras: 
			•	Rectangulo 
			•	Triangulo 
			•	Circulo 
*/
		double largo = 0;
		double ancho = 0;
		double base = 0;
		double altura = 0;
		double radio=0;
		
		Scanner entrada=new Scanner(System.in);
		
		System.out.println("introduce largo del rectangulo: ");
		largo = entrada.nextDouble();
		
		System.out.println("introduce ancho del rectangulo: ");
		ancho = entrada.nextDouble();
		
		double areaRectangulo = largo*ancho;
		System.out.println("el area para un rectangulo de "+largo +" de largo y " + ancho +
				" de anchura es " + areaRectangulo);
		
		System.out.println("introduce base del triangulo: ");
		base = entrada.nextDouble(); 
		System.out.println("introduce altura del triangulo: ");
		altura = entrada.nextDouble();
		
		double areaTriangulo = (base * altura)/2;
		System.out.println("el area para un triangulo de "+base +" de base y " + altura +
				" de altura es " + areaTriangulo);
		
		System.out.println("introduce radio del circulo: ");
		radio =  entrada.nextDouble();
		double areaCirculo = Math.PI * Math.pow(radio,2);
		System.out.println("El area de un circulo de " + radio + " de radio es " +areaCirculo);
	}

}
