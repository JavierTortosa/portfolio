package pregunta1;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Pregunta1 {

	public static void main(String[] args) {
/*
		Si x, y, z son variables de tipo double con valores x= 88, y = 3.5, z = -5.2, 
		determina el valor de las siguientes expresiones aritméticas. 
		Obtén el resultado de cada expresión con un máximo de cuatro decimales. 
				 
				a)	x + y + z                                
				b)	2 * y + 3 * (x – z)                                            
				c)	x / y                                    
				d)	x % y 
				e)	x / (y + z)                               
				f)	(x / y) + z 
				g)	2 * x / 3 * y                             
				h)	2 * x / (3 * y) 
				i)	x * y % z                                 
				j)	x * (y % z) 
				k)	3 * x – z – 2 * x                         
				l)	2 * x / 5 % y 
				m) x - 100 % y % z                           
				n) x - y - z * 2 R. 
*/
		
		double x= 88;
		double y = 3.5;
		double z = -5.2;
		double resultado;
		
		resultado= x + y + z;     
		
		System.out.print("a) ");
		System.out.print("x + y + z = ");
		System.out.println(new BigDecimal(resultado).setScale(4, RoundingMode.CEILING));
		System.out.println("");
		
		resultado= (2 * y) + 3 * (x - z); 
		
		System.out.print("b) ");
		System.out.print("(2 * y) + 3 * (x - z) = ");
		System.out.println(new BigDecimal(resultado).setScale(4, RoundingMode.CEILING));
		System.out.println("");
		
		resultado= x / y;
		System.out.print("c) ");
		System.out.print("x / y = ");
		System.out.println(new BigDecimal(resultado).setScale(4, RoundingMode.CEILING));
		System.out.println("");
		
		
		resultado= x % y; 
		System.out.print("d) ");
		System.out.print("x % y = ");
		System.out.println(new BigDecimal(resultado).setScale(4, RoundingMode.CEILING));
		System.out.println("");
		
		resultado= x / (y + z);   
		System.out.print("e) ");
		System.out.print("x / (y + z) = ");
		System.out.println(new BigDecimal(resultado).setScale(4, RoundingMode.CEILING));
		System.out.println("");
		
		resultado= (x / y) + z; 
		System.out.print("f) ");
		System.out.print("(x / y) + z = ");
		System.out.println(new BigDecimal(resultado).setScale(4, RoundingMode.CEILING));
		System.out.println("");
		
		resultado= 2 * x / 3 * y; 
		System.out.print("g) ");
		System.out.print("2 * x / 3 * y = ");
		System.out.println(new BigDecimal(resultado).setScale(4, RoundingMode.CEILING));
		System.out.println("");
		
		resultado= 2 * x / (3 * y); 
		System.out.print("h) ");
		System.out.print("2 * x / (3 * y) = ");
		System.out.println(new BigDecimal(resultado).setScale(4, RoundingMode.CEILING));
		System.out.println("");
		
		resultado= x * y % z;   
		System.out.print("i) ");
		System.out.print("x * y % z = ");
		System.out.println(new BigDecimal(resultado).setScale(4, RoundingMode.CEILING));
		System.out.println("");
		
		resultado= x * (y % z); 
		System.out.print("j) ");
		System.out.print("x * (y % z) = ");
		System.out.println(new BigDecimal(resultado).setScale(4, RoundingMode.CEILING));
		System.out.println("");
		
		resultado= 3 * x - z - 2 * x;  
		System.out.print("k) ");
		System.out.print("3 * x - z - 2 * x = ");
		System.out.println(new BigDecimal(resultado).setScale(4, RoundingMode.CEILING));
		System.out.println("");
		
		resultado= 2 * x / 5 % y; 
		System.out.print("l) ");
		System.out.print("2 * x / 5 % y = ");
		System.out.println(new BigDecimal(resultado).setScale(4, RoundingMode.CEILING));
		System.out.println("");
		
		resultado= x - 100 % y % z;     
		System.out.print("m) ");
		System.out.print("x - 100 % y % z = ");
		System.out.println(new BigDecimal(resultado).setScale(4, RoundingMode.CEILING));
		System.out.println("");
		
		resultado= x - y - z * 2;
		System.out.print("n) ");
		System.out.print("x - y - z * 2 = ");
		System.out.println(new BigDecimal(resultado).setScale(4, RoundingMode.CEILING));
		System.out.println("");
		
		
		}

}
