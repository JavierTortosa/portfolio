package pregunta6;

public class Pregunta6 {

	public static void main(String[] args) {

/*		
		Realizar una conversión explicita utilizando la variable 
		double d = 100.04; R. 
*/
		double d = 100.04;
		int dConvertida1 = (int)d;
		char dConvertida2 = (char)d;
		
		System.out.println("d convertida en int  = " + dConvertida1);
		System.out.println("d convertida en char = " + dConvertida2);
		
		
	}
}
