package Pregunta7;

/*
¿Qué son los atributos?   
R. 

los atributos son las "variables" de un objeto. son parte de la informacion que tiene un objeto de si mismo

de una clase Televisor podrian ser la marca o el modelo....
*/