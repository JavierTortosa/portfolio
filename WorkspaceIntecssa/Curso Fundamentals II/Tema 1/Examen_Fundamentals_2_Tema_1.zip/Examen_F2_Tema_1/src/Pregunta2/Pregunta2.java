package Pregunta2;

/*
PREGUNTA 2
----------

Listar los modificadores de acceso para declarar una clase. R. 

Private
Public
Protected
Hay un cuarto modificador que es de por defecto que no tiene palabra reservada
*/