package Pregunta1;

/*
PREGUNTA 1
----------

Explique que son los modificadores de acceso R. 

son modificadores que ayudan a restringir el alcance de una clase, constructor, variable, método o miembro de datos.
*/

