package Pregunta3;

/*
PREGUNTA 3
----------

Marcar el error dentro de las características de los constructores. 
a)	Un constructor, tiene el mismo nombre de la clase a la cual pertenece.  
b)	Puede ser heredado  **************************************************** UN CONSTRUCTOR NO SE HEREDA
c)	No retorna ningún valor. 
*/
