package Pregunta8;

/*
PREGUNTA 8
----------

Con el siguiente código: 
	 
	 
public class miPrimeraClase {  
 
 
 String nombre;  
 int edad;  
 
 
} 

Crear el método constructor correspondiente
*/

public class miPrimeraClase {

	String nombre;
	int edad;

	public miPrimeraClase(String nombre, int edad) {
		this.nombre = nombre;
		this.edad = edad;
	}

}
