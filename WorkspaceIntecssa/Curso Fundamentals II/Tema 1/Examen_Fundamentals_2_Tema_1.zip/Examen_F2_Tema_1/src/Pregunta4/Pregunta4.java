package Pregunta4;

/*
PREGUNTA 4
----------

¿Indique a que nos referimos con los constructores?   
R. 

 Es el método que invocamos para inicializar las variables de una nueva instancia

*/