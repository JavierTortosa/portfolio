package Pregunta_2;

/*PREGUNTA 2
 * 
 * ¿Cuáles serían las desventajas de las expresiones lambdas?
 * 
 * Si utilizamos interfaces, las lambdas están desarrolladas para solamente trabajar con un único método 
 * en su interior.
 * 
 * Si tenemos varios métodos, los requisitos a cumplir son:
 * 	Todos los métodos deben de tener la misma cantidad de parámetros.
 *	Se deben declarar métodos a utilizar como default o static.
 *	El resto de métodos quedaran inutilizados.
 */

public class Pregunta_2 {

}
